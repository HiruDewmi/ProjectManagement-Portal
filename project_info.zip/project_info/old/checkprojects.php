<html>
<head>
	<style>
   		table{
			font-family: arial;
			border-collapse: collapse;
			width: 100%;
		}
		table th {
            background-color:#6fa3f7;
            color: black;

        }
		td,th{
			border: 1px solid #dddddd;
			text-align: left;
			padding: 8px;
		}
		tr:nth-child(even){background-color: #f2f2f2};

	</style>
</head>
<body>

<?php 
require("process_checkprojects.php");
include("login_state.php");
?>
<h1 style="text-align: center;">Project Details.</h1>

   <table>
     <tr>
         <th>ID</th>
         <th>Project Name</th>
         <th>Project Manager</th>
         <th>Business Owner</th>
         <th>Start Date</th>
         <th>Expected End Date</th>
         <th>Technical Resource</th>
         <th>Status</th>
     </tr>
     <?php 
     if ($result->num_rows > 0) {
     // output data of each row
     while($row = $result->fetch_assoc()) {
         echo "<tr><td>". $row["ID"]. "</td>";
         echo "<td>". $row["project_name"]. "</td>";
         echo "<td>". $row["project_manager"]. "</td>";
         echo "<td>". $row["business_owner"]. "</td>";
         echo "<td>". $row["start_date"]. "</td>";
         echo "<td>". $row["expected_end_date"]. "</td>";
         echo "<td>". $row["technical_resource"]. "</td></tr>";
}
}else{
  echo "0 results";
}
?>
  
      </table>

<button style="margin-top: 20px" type="button" class="button" onclick="location.href = 'interface.php';"> <<< Back to the home page</button>
  </form>
  
 </body>
</html>