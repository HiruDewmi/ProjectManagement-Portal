<?php
$username = $_POST['user'];
$password = $_POST['pass'];

$username = stripcslashes($username);
$password = stripcslashes($password);
//$username = mysqli_real_escape_string($username);
//$password = mysqli_real_escape_string($password);

require("db_con.php");

$sql = "SELECT `id`, `username`, `password` FROM `login` WHERE `username`='$username' AND `password`='$password'";


$result = $conn->query($sql) or die($conn->error);
$conn->close();
$row = $result->fetch_assoc();


if($row['username']==$username && $row['password']==$password){
	session_start();
	$_SESSION["user"] = $row['username'];
	header("Location:interface.php"); 
}
else{
	echo "Failed to login!";
}

?>