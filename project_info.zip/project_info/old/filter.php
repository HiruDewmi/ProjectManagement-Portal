<!DOCTYPE html>
<html>
<head>
    <title>filter</title>
</head>
<body>
       <?php   
$server = 'localhost';
$db = 'project_details';
$user = 'root';
$pass = '';
$mysqli =  mysqli_connect($server, $user, $pass,$db) or die("connection failed:".mysql_error());
?>
<?php  
$sq = "SELECT * FROM project_info";
$result = mysqli_query($mysqli,$sq);
$i = 0;
?>

<table id="example" class="display" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>ID</th>
                <th>neme</th>
                <th>manager</th>
                <th>owner</th>
                <th>Start date</th>
                <th>end date</th>
                <th>resources</th>
                <th><b>Update</b></th>
                <th><b>Delete</b></th>
            </tr>
        </thead>
<?php
require ('edit.php');
require('delete.php');
while ($ab = mysqli_fetch_array($result)) {
    echo "<tr>";
    echo '<td>'.$ab['ID']. '</td>';
    echo '<td>'.$ab['project_name']. '</td>';
    echo '<td>'.$ab['project_manager']. '</td>';
    echo '<td>'.$ab['business_owner']. '</td>';
    echo '<td>'.$ab['start_date']. '</td>';
    echo '<td>'.$ab['expected_end_date']. '</td>';
    echo '<td>'.$ab['technical_resource']. '</td>';
    echo '<td><a href="edit.php?ID=' .$ab['ID']. '">Edit</a></td>';
    echo '<td><a href="delete.php?ID=' .$ab['ID']. '">Delete</a></td>';

    echo "</tr>";
}

 ?>     
    
        </tbody>
    </table>
    </body>
    </html>