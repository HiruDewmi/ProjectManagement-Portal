<?php
include_once("db_con.php");
$result = mysqli_query($conn,"SELECT * FROM `project_info` ORDER BY ID DESC");
?>
<html>
<head>
	<style>
		table{
			font-family: arial;
			border-collapse: collapse;
			width: 100%;
		}
		table th {
            background-color:#6fa3f7;
            color: black;

        }
		td,th{
			border: 1px solid #dddddd;
			text-align: left;
			padding: 8px;
		}
		tr:nth-child(even){background-color: #f2f2f2};

	</style>
</head>
<body>
 <div class="container"> </div>
<h1 style="text-align: center;">Edit Project Details.</h1>
<table>
<tr>
<th>ID</th>
<th>project_name</th>
<th>project_manager</th>
<th>business_owner</th>
<th>start_date</th>
<th>expected_end_date</th>
<th>technical_resource</th>
<th>update</th>
<th>delete</th>
<th>check</th>
</tr>
<?php 

if ($result->num_rows > 0) {
     // output data of each row
     while($row = $result->fetch_assoc()) {
         echo "<tr><td>". $row["ID"]. "</td>";
         echo "<td>". $row["project_name"]. "</td>";
         echo "<td>". $row["project_manager"]. "</td>";
         echo "<td>". $row["business_owner"]. "</td>";
         echo "<td>". $row["start_date"]. "</td>";
         echo "<td>". $row["expected_end_date"]. "</td>";
         echo "<td>". $row["technical_resource"]. "</td></tr>";
         echo"<input type="submit" value="update" name="update'.$i.'" />";
         
     }
} else {
     echo "0 results";
}

?>
</table>
<button style="margin-top: 20px" type="button" class="button" onclick="location.href = 'interface.php';"> <<< Back to home page</button>
</body>
</html>