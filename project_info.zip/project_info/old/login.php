<!DOCTYPE html>
<html>
<head>
 <title>login page</title>
 <link rel="stylesheet" type="text/css" href="style_login.css">
 </head>

 <body>
 <div id="outer">
  <br><br>
  <p><a href="register.php"><strong>Register</strong></a> | <a href="login.php"><strong>Login</strong></a></p>
  
     <div id = "frm">
       <form action="process_login.php" method="POST">
         <p>
           <img  src = "dialoglogoc.jpg"  width="65" height="50" >
         </p>
         <p>
         <h1>Login Form...</h1>
         </p>
         <p>
         <label><b>Username :</b></label>
          <input type="text" id = "user" name="user" />
         </p>
         <p>
         <label><b>Password  :</b></label>
         <input type="password" id = "pass" name="pass" />
         </p>
         <p>
          <input type="submit" id = "btn" name="login" /></p>
       </form>
     </div>  
</div>
</body>
</html>
