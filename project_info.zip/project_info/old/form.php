<!DOCTYPE html>
<html>
<head>
    <title>form new</title>
    <link rel="stylesheet" type="text/css" href="style2_form.css">
    <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
  
  <script>
  //$(document).ready(function() {
    $(function()  {
    $("#datepicker , #datepicker2").datepicker({dateFormat:'YY-MM-DD'}).val();
    var dateFormat = $( "#datepicker , #datepicker2" ).datepicker( "option", "dateFormat" );
    $( "#datepicker , #datepicker2" ).datepicker( "option", "dateFormat", "yy-mm-dd" );
  });
  </script>
</head>

<body>

<?php 
require("test.php");
?>

<form action="process_form.php" method="post" class="basic-grey" >
    <h1 style="text-align: center;">New Project Information.
         <span>Please fill all the texts in the fields.</span>
     </h1>
     <label>
         <span>ID:</span>
         <input type="number" name="ID" value="<?php echo $row['ID']+1;?>" />
     </label>
     <label>
         <span>Project name:</span>
         <input id="name" type="text" name="project_name" placeholder="Full Name" required/>
     </label>
     <label>
         <span>Project manager:</span>
         <input id="manager" type="text" name="project_manager" placeholder="Full Name" required />
     </label>
     <label>
         <span>Business owner:</span>
         <input id="owner" type="text" name="business_owner" placeholder="Full Name" required />
     </label>
     <label>
         <span>Start date:</span>
         <input id="datepicker" type="text" name="start_date" placeholder="YYYY-MM-DD" required pattern="\d{4}-\d{1,2}-\d{1,2}" />
     </label> 
     <label>
         <span>Expected end date:</span>
         <input id="datepicker2" type="text" name="expected_end_date" placeholder="YYYY-MM-DD" required pattern="\d{4}-\d{1,2}-\d{1,2}" />
     </label>
     <label>
         <span>Technical resources:</span>
         <input id="resources" type="text" name="technical_resources"  required />
     </label>
      
      <label>
         <span>&nbsp;</span> 
         <input  type="submit" class="button" name="Submit">
         <input type="button" class="button" onclick="location.href = 'checkprojects.php';" value="Cancel" /> 
     </label>    
</form>
<button type="button" class="button" onclick="location.href = 'interface.php';"> <<< Back to home page</button>
</div>

</body>
</html>
