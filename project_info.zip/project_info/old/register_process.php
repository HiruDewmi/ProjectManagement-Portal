<?php 
$servername = "localhost";
$uname = "root";
$passwd ="";
$dbname = "project_details";

// Create connection
$con = new mysqli($servername, $uname, $passwd, $dbname);
// Check connection
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
} 

 $usernam = $_POST['usr'];
 $passwor = $_POST['pas'];
 $passwor2 = $_POST['pas2'];

    if (isset($_POST['btn'])) {
    //	$username = mysql_real_escape_string($_POST['usr']);
    //	$password = mysql_real_escape_string($_POST['pas']);
    //	$password2 = mysql_real_escape_string($_POST['pas2']);

    	if($password == $password2){
              //create
    		$password = nd5($password);
    		$sq = "INSERT INTO 'login'('ID','username','password') VALUES(NULL , '$usernam','$passwor')";
    		mysqli_query($con,$sq);
    		$_SESSION['message']= "loged in";
    		$_SESSION['username']= $usernam;
    		header("location: login.php");

    	}else{
    		//fail
    		$_SESSION['message']= "passwords not match";
    	}
    }


 ?>