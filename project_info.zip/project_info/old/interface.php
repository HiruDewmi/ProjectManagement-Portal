			
<!DOCTYPE html>
<html>
<head>
	<title>interface</title>
	<style>
	    #outer{
     
	         background-image: url("ground.jpg");
             height: 645px;
     
        }
	    
		#button1{
			background-color: #CEE5E8;
			width: 200px;
			height: 50px;
			border: 2px solid #ffffff;
			margin-right: 50px;
			margin-top: 150px;
			font-size: 20px;
			border-radius: 8px;
		}
		#button2{	
            background-color: #CEE5E8;
			width: 200px;
			height: 50px;
			border: 2px solid #ffffff;
			font-size: 20px;
			border-radius: 8px;
			margin-right: 50px;
			margin-top: 150px;
		}
		
		.container{
			margin-top: 100px;
    		justify-content: center;
    		align-items: center;
    		position:absolute;
    		bottom: 0;
    		top: 0;
    		left: 0;
    		right: 0;
		}
		
	</style>
</head>
<body>
<div id="outer">
<div style="text-align: center;" class="container">
<h1 >Welcome to home page!!</h1>
<p >Select a button to enter new project details or to check current project details. </p>
 <button type="button" id="button1" onclick="location.href = 'form.php';">New project</button>
 <button type="button" id="button2" onclick="location.href = 'checkprojects.php';">Check projects</button>
 <button type="button" id="button2" onclick="location.href = 'practise.php';">Edit projects</button><br>
</div>

 <?php include("login_state.php");?>
 </div>
</body>
</html>