<?php
//include('connect-db.php');
$server = 'localhost';
$db = 'project_details';
$user = 'root';
$pass = '';
$mysqli =  mysqli_connect($server, $user, $pass,$db) or die("connection failed:".mysql_error());

	$id = $_GET['ID'];
// delete the entry
$result = mysqli_query($mysqli,"DELETE FROM project_info WHERE ID=$id")
or die(mysql_error());
//header("Location: practise.php");
echo "<script>
alert('Successefully deleted!');
window.location.href = 'practise.php';
</script>";

?>