
<!DOCTYPE html>
<html>
<head>
<title>Register</title>
 <link rel="stylesheet" type="text/css" href="register.css">
 
</head>
<body>
<div id="outer">
    <br><br>
    <p><a href="register.php"><strong>Register</strong></a> | <a href="login.php"><strong>Login</strong></a></p>
 	
 	<div id = "frm1">
 	<form action="register.php" method="POST">
 	<p>
      <img  src = "dialoglogoc.jpg"  width="65" height="50" >  
    </p>
    <p>
 		<h1>Registration Form...</h1>
 	</p>
 	<p>
 	<label><b>Username:</b></label><br>
 	<input type="text" name="usr" class="input"><br />
 	</p>
 	<p>
 	<label><b>Password:</b></label><br>
 	<input type="password" name="pas" class="input"><br />
 	</p>
 	<p>
 	<label><b>Confirm Password:</b></label><br>
 	<input type="password" name="pas2" class="input"><br />
 	</p>
 	<p>
 	<input type="submit" id = "btn"  value="Register" onclick="interface.php">
 	</p>
 	</form>
 	</div>

 </body>
 </html>