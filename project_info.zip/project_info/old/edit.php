<?php
// creates the edit record form
function renderForm($id, $project_name, $project_manager,$business_owner,$start_date,$expected_end_date,$technical_resource ,$error)
//include_once("db_con.php");

{
?>

<!DOCTYPE>
<html>
<head>
<title>Edit Record</title>
<style>
	#frm{
           margin-top: 40px;
	       margin-left:auto;
           margin-right:auto;
           max-width: 400px;
           background: #F7F7F7;
           padding: 30px 30px 30px 30px;
           font: 18px Georgia, "Times New Roman", Times, serif;
           color: #000;
           text-shadow: 1px 1px 1px #FFF;
           border:2px solid #E4E4E4;
	}
	.container{
            margin-top: 100px;
    		justify-content: center;
    		align-items: center;
    		position:absolute;
    		bottom: 0;
    		top: 0;
    		left: 0;
    		right: 0;
		
	}
	#button1{
		    background-color: #CEE5E8;
			width: 200px;
			height: 50px;
			border: 2px solid #ffffff;
			font-size: 20px;
			border-radius: 8px;
			margin-left: 80px;
			margin-top: 20px;
	}
	.input{
     margin: 10px 0px 10px 0px;
     border-radius: 5px;
     display: block;
     text-align: left;
     }
    
</style>
<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
  
  <script>
  //$(document).ready(function() {
    $(function()  {
    $("#datepicker , #datepicker2").datepicker({dateFormat:'YY-MM-DD'}).val();
    var dateFormat = $( "#datepicker , #datepicker2" ).datepicker( "option", "dateFormat" );
    $( "#datepicker , #datepicker2" ).datepicker( "option", "dateFormat", "yy-mm-dd" );
  });
  </script>
</head>
<body>
<form action="edit.php" method="post">
<input type="hidden" name="id" value="<?php echo $id; ?>"/>
<div id = "frm">
<p>Edit data:</p>
<h2><strong>ID:</strong> <?php echo($id) ?></h2>
<label>
     <strong>Project Name:</strong>
     <input type="text" name="name" value="<?php echo $project_name; ?>" />
</label>
</br></br>
<label>
     <strong>Project Manager:</strong> 
     <input type="text" name="manager" value="<?php echo $project_manager; ?>" />
</label>
</br></br>
<label>
     <strong>Business Owner:</strong>
     <input type="text" name="owner" value="<?php echo $business_owner; ?>" />
</label>
</br></br>
<label>
     <strong>Start Date:</strong> 
     <input  type="text" name="start" id = "datepicker" placeholder="<?php echo $start_date; ?>"  />
</label>
</br></br>
<label>
     <strong>Expected End Date:</strong> 
     <input  type="text" name="end" id = "datepicker2" placeholder="<?php echo $expected_end_date; ?>" />
</label>
</br></br>
<label>
     <strong>Technical Resource:</strong> 
     <input type="text" name="resource" value="<?php echo $technical_resource; ?>" />
</label>
</br></br>
<label>
<input type="submit" id = "button1" name="submit" value="Submit"></label>
</div>
</form>
<button style="margin-top: 20px" type="button" class="button" onclick="location.href = 'practise.php';"> <<< Back </button>
</body>
</html>
<?php
}
$server = 'localhost';
$db = 'project_details';
$user = 'root';
$pass = '';
$mysqli =  mysqli_connect($server, $user, $pass,$db) or die("connection failed:".mysql_error());

// check if the form has been submitted. If it has, process the form and save it to the database
if (isset($_POST['submit'])){
//if (is_numeric($_POST['$id'])){

$id= $_POST['id'];

$id = mysqli_real_escape_string($mysqli,$_POST['id']);
$name = mysqli_real_escape_string($mysqli,$_POST['name']);
$manager = mysqli_real_escape_string($mysqli,$_POST['manager']);
$owner = mysqli_real_escape_string($mysqli,$_POST['owner']);
$start = mysqli_real_escape_string($mysqli,$_POST['start']);
$end = mysqli_real_escape_string($mysqli,$_POST['end']);
$resource = mysqli_real_escape_string($mysqli,$_POST['resource']);

if ($name == '' || $manager == '' || $owner == '' || $start == '' || $end == '' || $resource == ''){
$error = 'ERROR: Please fill in all required fields!';
echo($error);

renderForm($id, $name, $manager,$owner,$start,$end,$resource, $error);
}
else{
mysqli_query($mysqli,"UPDATE project_info SET project_name='$name', project_manager='$manager',business_owner='$owner', start_date='$start', expected_end_date='$end', technical_resource='$resource' WHERE ID='$id'") or die(mysql_error());
echo "<script>
alert('Successefully edited !');
window.location.href = 'practise.php';
</script>";
//header("Location: practise.php");

}
}
else{
if (isset($_GET['ID']) && is_numeric($_GET['ID']) && $_GET['ID'] > 0)
{

$id = $_GET['ID'];
$result = mysqli_query($mysqli,"SELECT * FROM project_info WHERE ID=$id") ;
$res = mysqli_fetch_array($result); 

if($res){// get data from db

$name = $res['project_name'];
$manager = $res['project_manager'];// show form
$owner = $res['business_owner'];
$start = $res['start_date'];
$end = $res['expected_end_date'];
$resource = $res['technical_resource'];

renderForm($id, $name, $manager,$owner,$start,$end,$resource, '');
}
else  // if no match, display result
{
echo "No results!";
}
}
}
?>